//////////////////////////
//                      //
//  Censorship Filter   //
//                      //
//////////////////////////

This is a very simple Text Filter that searches text
being output to the screen, replacing "bad" words
with other words.

To customise the word list, use the censor settings page
in the filters administration page.

If no customised list has been provided, a default list
specified in the current language pack will be used. Note that
the custom list is an alternative to the default list not
an addition to it.
